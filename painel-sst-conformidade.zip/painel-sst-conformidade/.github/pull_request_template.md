## O que muda

<!-- Descreva a alteração em poucas linhas. -->

## Tipo de mudança

- [ ] Correção de erro
- [ ] Novo indicador, página ou visual
- [ ] Regra de negócio ou meta
- [ ] Base de dados ou medidas DAX
- [ ] Documentação

## Conferência

- [ ] Abri o `index.html` no navegador e testei as páginas afetadas.
- [ ] Testei com "Todas as unidades" e com uma unidade selecionada.
- [ ] Se a lógica de dados mudou, regenerei a base (`data/`) e a aba `Conferencia` mostra "Base confere com o painel".
- [ ] Atualizei o `README.md` e o `CHANGELOG.md`, quando necessário.
- [ ] Não incluí dados reais de pessoas ou empresas.

## Telas

<!-- Antes e depois, quando a mudança for visual. -->
